package baseDeDonne;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connecteur {
	private String url = "jdbc:mysql://localhost:3306/lakilasy?characterEncoding=UTF-8";
	private String username = "root";
	private String password = "";
	public Connecteur() {}
	
	public void setInfo(String url, String usr, String pass) {
		this.url = url;
		this.username = usr;
		this.password = pass;
	}
	
	public String[] getData() {
		String[] data = {};
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(this.url, this.username, this.password);
			Statement stat = con.createStatement();
			ResultSet result = stat.executeQuery("SELECT * FROM utilisateurs");
			
			while(result.next()) {
				String s = result.getInt(1) +";"+ result.getString(2) +";"+ result.getString(3)+";"+ result.getString(4)+";"+ result.getString(5);
			}
			
		}catch(SQLException e) {
			System.out.println("Erreur de connexion SQL : " + e.getMessage());
		}
		return data;
	}
}
