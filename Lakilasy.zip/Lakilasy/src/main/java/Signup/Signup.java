package Signup;


import jakarta.servlet.ServletException;
//import baseDeDonne.Connecteur;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * Servlet implementation class Signup
 */
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("username");
		String passwd = request.getParameter("password");
		String cpasswd = request.getParameter("cpassword");
		String lesson = "Python";
		String chapter = "1";

		
		String chemin = "/home/mit/data.txt";
		
		
		Manipulation mf = new Manipulation(chemin);
		
		int retour = 0;
		
		String v = "";
		String[] Ts = mf.getLines();	
		for(String i:Ts) {
			if(i!=null) {
				if (name.equals(i.split(";")[0])) {
					retour = 1;
					break;
				}
			}
		}
		
		if (passwd.equals(cpasswd)){
			if (retour==0) {				
				mf.write(name+";"+passwd+";"+lesson+";"+chapter+"\n");
				HttpSession session = request.getSession();
				session.setAttribute("id", name);
			}
		}else {
			retour = 3;
		}
		if (retour==1) {
			response.sendRedirect("signup.jsp?err=1");
		}else if (retour==3) {
			response.sendRedirect("signup.jsp?err=2");
		}
		else {
			String[] tv = v.split(";");
			response.sendRedirect("Python.jsp");
		}
    }
}
