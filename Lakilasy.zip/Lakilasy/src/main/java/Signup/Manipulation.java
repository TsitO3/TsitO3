package Signup;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Manipulation {
	String titre;
	public Manipulation(String titre) throws IOException {
		this.titre = titre;
		if(testFile() == 0) {
			write("admin;123456;python;1\n");
		}
	}
	
	public void vider() throws IOException{
		try(FileWriter file = new FileWriter(titre,false)){
			write("admin;123456;Python;1\n");
		}
	}
	
	public void write(String texte) throws IOException {
		try(FileWriter file = new FileWriter(titre,true)){
			file.write(texte);
		}
	}

	public String[] getLines() throws IOException {
		String chaine = null;
		try(FileReader file = new FileReader(titre)){
			int data = 0;
			while((data = file.read())!=-1) {
				chaine+=(char)data;
			}
		}
		return chaine.split("\n");
	}

	public int testFile() {
		File file = new File(this.titre);
		if(file.exists()) {
			return 1;
		}
		return 0;
	}
}

