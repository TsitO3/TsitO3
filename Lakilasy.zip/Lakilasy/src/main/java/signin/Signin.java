package signin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import Signup.Manipulation;

/**
 * Servlet implementation class Signin
 */
public class Signin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("username");
		String passwd = request.getParameter("password");
		
		String chemin = "/home/mit/data.txt";
		
		
		Manipulation mf = new Manipulation(chemin);
		
		int retour = 1;
		
		String[] line;
		String v = "";
		String[] Ts = mf.getLines();	
		for(String i:Ts) {
			if(i!=null) {
				line = i.split(";");
				if (name.equals(line[0]) && passwd.equals(line[1])) {
					v = i;
					HttpSession session = request.getSession();
					session.setAttribute("id", line[0]);
					retour = 0;
					break;
				}
			}
		}
		if (retour==1) {
			response.sendRedirect("login.jsp?err=1");
		}else {
			String[] tv = v.split(";");
			response.sendRedirect(tv[2]+".jsp#"+tv[3]);
		}
	}

}
