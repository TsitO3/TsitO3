package Login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import Signup.Manipulation;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String la = request.getParameter("identifiant");
		String chemin = "/home/mit/data.txt";
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
    	if (id!=null){    		
    		Manipulation mf = new Manipulation(chemin);
    		String[] Ts = mf.getLines();
    		mf.vider();
    		for (int i=0;i<Ts.length;i++) {
    			String[] TTs = Ts[i].split(";");
    			if(id.equals(TTs[0])) {
    				String nouv = TTs[0]+";"+TTs[1]+";"+la+";"+TTs[3];
    				Ts[i] = nouv;
    			}
    			mf.write(Ts[i]+"\n");
    		}
    	}
    	response.sendRedirect(la+".jsp");
	}

}
